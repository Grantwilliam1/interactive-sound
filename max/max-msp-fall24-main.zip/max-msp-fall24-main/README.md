# max-msp-fl24
 Max examples for Interactive Sound

 whatcha think?
