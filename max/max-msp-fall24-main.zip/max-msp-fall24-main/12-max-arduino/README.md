# arduino-max-fall24

## hello arduino and max
 
 each "hello" project directory contains both an arduino sketch (.ino), a corresoponding cycling 74 max patch (.maxpat), and if you are using ableton live suite a max for live patch (.amxd)
 
projects in order
1. hello_blink
2. hello_blink_max
3. hello_button_max
4. hello_potentiometer_max
5. hello_photoresistor_max
6. hello_instrument_max
 
 each arduino sketch (.ino) has a corresponding tinkercad url in comments to help build physical arduino circuit, command/ctrl click link to launch browser and then click tinker this!




